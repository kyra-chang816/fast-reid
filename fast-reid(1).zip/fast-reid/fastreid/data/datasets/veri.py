# encoding: utf-8
"""
@author:  yihao
"""

"""
用于创建VeRi数据集的dataset，并且把它写入DATASET_REGISTRY中，以后方便用'VeRi'来直接调用。

这个dataset读取位于/fast-reid/projects/StrongBaseline/datasets/VeRi/目录下的文件来创建，
返回train_set, query_set 和 gallery_set
"""

import glob
import os.path as osp
import re
import warnings

from .bases import ImageDataset
from ..datasets import DATASET_REGISTRY


@DATASET_REGISTRY.register()
class VeRi(ImageDataset):
    """VeRi.

    Reference:
       Liu, Xinchen, et al. "Large-scale vehicle re-identification in urban surveillance videos." ICME 2016.
       URL:https://vehiclereid.github.io/VeRi/

    Dataset statistics:
        - identities: 776
        - images: 37778 (train) + 1678 (query) + 11579 (gallery).
        - cameras: 20
    """
    dataset_dir = ''

    def __init__(self, root='datasets', **kwargs):
        #super(VeRi, self).__init__()
        self.root = root
        #self.root = '../../../projects/StrongBaseline/datasets'
        self.dataset_dir = osp.join(self.root, self.dataset_dir)

        # allow alternative directory structure
        self.data_dir = self.dataset_dir
        data_dir = osp.join(self.data_dir, 'VeRi')
        if osp.isdir(data_dir):
            self.data_dir = data_dir

        self.train_dir = osp.join(self.data_dir, 'image_train')
        self.query_dir = osp.join(self.data_dir, 'image_query')
        self.gallery_dir = osp.join(self.data_dir, 'image_test')
        self.train_list_path = osp.join(self.data_dir, 'list', 'veri_train_list.txt')
        self.query_list_path = osp.join(self.data_dir, 'list', 'veri_query_list.txt')
        self.gallery_list_path = osp.join(self.data_dir, 'list', 'veri_test_list.txt')

        required_files = [
            self.dataset_dir,
            self.train_dir,
            self.query_dir,
            self.gallery_dir
        ]
        self.check_before_run(required_files)

        train = self.process_dir(self.train_dir, self.train_list_path, True)
        query = self.process_dir(self.query_dir, self.query_list_path, False)
        gallery = self.process_dir(self.gallery_dir, self.gallery_list_path, False)

        super(VeRi, self).__init__(train, query, gallery, **kwargs)

    def process_dir(self, dir_path, list_path, is_train=True):
        with open(list_path, 'r') as txt:
            lines = txt.readlines()

        data = []

        if is_train:
            for line in lines:
                line = line.strip().split(' ')
                img_path = line[0]
                pid = int(line[1])
                camid = int(line[0].strip().split('_')[1][1:])
                img_path = osp.join(dir_path, img_path)
                data.append((img_path, pid, camid))
        else:
            for line in lines:
                line = line.strip()
                img_path = line
                pid = int(line.split('_')[0])
                camid = int(line.split('_')[1][1:])
                img_path = osp.join(dir_path, img_path)
                data.append((img_path, pid, camid))

        return data


        
